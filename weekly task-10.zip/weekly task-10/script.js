function rollDice() {
    const dice1 = document.getElementById('member-1');
    const dice2 = document.getElementById('member-2');
    const dice3 = document.getElementById('member-3');
    const winnerDiv = document.getElementById('winner');

    const roll1 = Math.floor(Math.random() * 6) + 1;
    const roll2 = Math.floor(Math.random() * 6) + 1;
    const roll3 = Math.floor(Math.random() * 6) + 1;

    dice1.textContent = roll1;
    dice2.textContent = roll2;
    dice3.textContent = roll3;

    const maxRoll = Math.max(roll1, roll2, roll3);
    const minRoll = Math.min(roll1, roll2, roll3);

    if (roll1 === roll2 && roll2 === roll3) {
        dice1.style.backgroundColor = 'blue';
        dice2.style.backgroundColor = 'blue';
        dice3.style.backgroundColor = 'blue';
        winnerDiv.textContent = 'It\'s a draw!';
    } else {
        if (roll1 === maxRoll) {
            dice1.style.backgroundColor = 'green';
            dice2.style.backgroundColor = 'red';
            dice3.style.backgroundColor = 'red';
            winnerDiv.textContent = 'Member A wins!';
        } else if (roll2 === maxRoll) {
            dice1.style.backgroundColor = 'red';
            dice2.style.backgroundColor = 'green';
            dice3.style.backgroundColor = 'red';
            winnerDiv.textContent = 'Member B wins!';
        } else {
            dice1.style.backgroundColor = 'red';
            dice2.style.backgroundColor = 'red';
            dice3.style.backgroundColor = 'green';
            winnerDiv.textContent = 'Member C wins!';
        }
    }
}